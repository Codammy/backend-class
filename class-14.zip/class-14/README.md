# Basic CRUD with Express

This is a basic CRUD application using express, no database, but file storage.

## Installation
after a successful clone, run the following command to install dependencies.
```bash
cd class-4
npm install
npm start
```

**Note:** _make sure you have node installed on your machine, and an empty json array in the data folder_
